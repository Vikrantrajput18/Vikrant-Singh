package com.capg.omts.sreen_show.model;

public enum SeatStatus {

		AVAILABLE,BOOKED,BLOCKED;
}
