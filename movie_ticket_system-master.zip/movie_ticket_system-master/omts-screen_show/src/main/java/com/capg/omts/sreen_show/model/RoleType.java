package com.capg.omts.sreen_show.model;

public enum RoleType {

	ROLE_CUSTOMER,
    ROLE_ADMIN

}
