package com.capg.omts.sreen_show;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OmtsScreenShowApplicationTests {

	@Test
	void contextLoads() {
	}

}
