package com.cg.movieticketsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieTicketSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
